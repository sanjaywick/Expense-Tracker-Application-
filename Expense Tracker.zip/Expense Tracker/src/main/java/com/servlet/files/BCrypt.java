package com.servlet.files;

public interface BCrypt {

}
